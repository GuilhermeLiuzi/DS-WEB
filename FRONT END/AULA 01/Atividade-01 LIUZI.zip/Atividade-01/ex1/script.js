let nome = prompt ("Digite seu primeiro nome: ");
let sobrenome = prompt("Digite seu sobrenome: ");
console.log(nome + " " + sobrenome);
alert(nome + sobrenome)