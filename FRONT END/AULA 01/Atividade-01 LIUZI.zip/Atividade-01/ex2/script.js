let n1 = Number(prompt("digite o primeiro número"));
let n2 = Number(prompt("digite o segundo número"));
alert(n1 + n2);

let n3 = Number(prompt("digite o primeiro número"));
let n4 = Number(prompt("digite o segundo número"));
alert(n1 - n2);

let n5 = Number(prompt("digite o primeiro número"));
let n6 = Number(prompt("digite o segundo número"));
alert(n1 * n2);

let n7 = Number(prompt("digite o primeiro número"));
let n8 = Number(prompt("digite o segundo número"));
alert(n1 / n2);


