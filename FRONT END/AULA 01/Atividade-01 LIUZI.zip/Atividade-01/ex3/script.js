let n1 = Number(prompt("digite um número"));
let cubo = numero ** 3;
alert (cubo);
